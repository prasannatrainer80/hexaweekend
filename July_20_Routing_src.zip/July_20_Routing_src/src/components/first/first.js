import React, {Component} from 'react';
import Menu from '../menu/menu';

const First = () => {
  return(
    <div>
      <Menu />
      This is My First Component...
    </div>
  )
} 

export default First;