import React from 'react';
import Menu from '../menu/menu';

const Second = () => {
  return(
    <div>
      <Menu />
      <p>This is My Second Component...</p>
    </div>
  )
}
export default Second;