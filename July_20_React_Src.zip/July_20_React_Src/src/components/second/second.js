import React from 'react';

const Second = () => {
  return(
    <div>
      <p>This is My Second Component...</p>
    </div>
  )
}
export default Second;