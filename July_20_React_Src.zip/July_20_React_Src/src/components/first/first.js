import React, {Component} from 'react';

const First = () => {
  return(
    <div>
      This is My First Component...
    </div>
  )
} 

export default First;