export const incr = () => ({type:'INCREMENT'});
export const decr = () => ({type:'DECREMENT'});
export const power = () => ({type:'POWER'})
