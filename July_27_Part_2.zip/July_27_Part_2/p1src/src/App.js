import logo from './logo.svg';
import './App.css';
import Names from './Names';

function App() {
  return (
    <div className="App">
      <Names />
    </div>
  );
}

export default App;
