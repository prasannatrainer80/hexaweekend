export const ajay = () => ({ type: 'AJAY' });
export const aarthi = () => ({ type: 'AARTHI' });
export const abhirami = () => ({type : 'ABHIRAMI'});